import AppKit
import ApplicationServices
import Combine

/// All callbacks and state changes run on the main run loop.
final class DragController: ObservableObject {
    enum DragKey: String, CaseIterable, Identifiable {
        case f6 = "F6", f7 = "F7", f8 = "F8", f9 = "F9"
        var id: String { rawValue }
        var code: CGKeyCode {
            switch self {
            case .f6: return 97
            case .f7: return 98
            case .f8: return 100
            case .f9: return 101
            }
        }
    }

    @Published private(set) var enabled = false
    @Published private(set) var dragging = false
    @Published private(set) var status = "Drag helper is off."
    @Published var key: DragKey {
        didSet {
            stop()
            UserDefaults.standard.set(key.rawValue, forKey: "dragKey")
        }
    }

    private var tap: CFMachPort?
    private var source: CFRunLoopSource?
    private var deadline: Timer?
    private var held = false
    private var swallowLeftUp = false
    private var swallowedKeys = Set<CGKeyCode>()
    private let marker: Int64 = 0x4B423936
    private let eventSource = CGEventSource(stateID: .privateState)

    init() {
        key = DragKey(rawValue: UserDefaults.standard.string(forKey: "dragKey") ?? "") ?? .f6
    }

    func requestAccessibility() {
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true]
        _ = AXIsProcessTrustedWithOptions(options as CFDictionary)
    }

    func start() {
        guard !enabled else { return }
        guard AXIsProcessTrusted() else {
            requestAccessibility()
            status = "Allow KB96 Control in Accessibility, then enable again."
            return
        }
        let types: [CGEventType] = [
            .keyDown, .keyUp, .flagsChanged, .mouseMoved,
            .leftMouseDown, .leftMouseUp, .leftMouseDragged,
            .rightMouseDown, .otherMouseDown
        ]
        let mask = types.reduce(CGEventMask(0)) { $0 | (CGEventMask(1) << $1.rawValue) }
        guard let newTap = CGEvent.tapCreate(
            tap: .cgSessionEventTap, place: .headInsertEventTap,
            options: .defaultTap, eventsOfInterest: mask,
            callback: { proxy, type, event, context in
                guard let context else { return Unmanaged.passUnretained(event) }
                let owner = Unmanaged<DragController>.fromOpaque(context).takeUnretainedValue()
                return owner.handle(proxy: proxy, type: type, event: event)
            }, userInfo: Unmanaged.passUnretained(self).toOpaque()
        ) else {
            status = "Cannot monitor input. Check Accessibility and Input Monitoring, then reopen the app."
            return
        }
        guard let runLoopSource = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, newTap, 0) else {
            CFMachPortInvalidate(newTap)
            status = "Could not create the input listener."
            return
        }
        tap = newTap
        source = runLoopSource
        CFRunLoopAddSource(CFRunLoopGetMain(), runLoopSource, .commonModes)
        CGEvent.tapEnable(tap: newTap, enable: true)
        enabled = true
        status = "Hold \(key.rawValue) to drag; release to drop."
    }

    func stop() {
        releaseDrag()
        if let tap { CGEvent.tapEnable(tap: tap, enable: false) }
        if let source { CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes) }
        if let tap { CFMachPortInvalidate(tap) }
        source = nil
        tap = nil
        held = false
        swallowLeftUp = false
        swallowedKeys.removeAll()
        enabled = false
        status = "Drag helper is off."
    }

    private func emit(_ type: CGEventType, at point: CGPoint, flags: CGEventFlags,
                      proxy: CGEventTapProxy? = nil) -> Bool {
        guard let event = CGEvent(mouseEventSource: eventSource, mouseType: type,
                                  mouseCursorPosition: point, mouseButton: .left) else { return false }
        event.flags = flags
        event.setIntegerValueField(.eventSourceUserData, value: marker)
        event.setIntegerValueField(.mouseEventClickState, value: 1)
        if let proxy {
            event.tapPostEvent(proxy)
        } else {
            event.post(tap: .cgSessionEventTap)
        }
        return true
    }

    private func releaseDrag(proxy: CGEventTapProxy? = nil, event: CGEvent? = nil) {
        deadline?.invalidate()
        deadline = nil
        guard dragging else { return }
        let current = event ?? CGEvent(source: nil)
        _ = emit(.leftMouseUp, at: current?.location ?? .zero,
                 flags: current?.flags ?? [], proxy: proxy)
        dragging = false
        status = enabled ? "Hold \(key.rawValue) to drag; release to drop." : "Drag helper is off."
    }

    private func handle(proxy: CGEventTapProxy, type: CGEventType,
                        event: CGEvent) -> Unmanaged<CGEvent>? {
        if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
            stop()
            status = "macOS interrupted the listener. Drag released; enable again when ready."
            return Unmanaged.passUnretained(event)
        }
        guard event.getIntegerValueField(.eventSourceUserData) != marker else {
            return Unmanaged.passUnretained(event)
        }
        let code = CGKeyCode(truncatingIfNeeded: event.getIntegerValueField(.keyboardEventKeycode))
        if type == .keyUp, swallowedKeys.remove(code) != nil { return nil }

        if type == .keyDown && code == 53 { // Escape, including the emergency chord.
            let emergency: CGEventFlags = [.maskControl, .maskAlternate, .maskCommand]
            if event.flags.intersection(emergency) == emergency {
                releaseDrag(proxy: proxy, event: event)
                // Disable after returning from the callback.
                DispatchQueue.main.async { [weak self] in self?.stop() }
                return nil
            }
            if held {
                releaseDrag(proxy: proxy, event: event)
                swallowedKeys.insert(code)
                // Keep the activation key latched until its key-up; repeats cannot restart.
                return nil
            }
        }

        if type == .keyDown && code == key.code {
            if held { return nil }
            // Leave modified shortcuts and an existing physical drag alone.
            let modifiers: CGEventFlags = [.maskCommand, .maskControl, .maskAlternate, .maskShift]
            guard event.flags.intersection(modifiers).isEmpty,
                  event.getIntegerValueField(.keyboardEventAutorepeat) == 0,
                  !CGEventSource.buttonState(.combinedSessionState, button: .left),
                  !CGEventSource.buttonState(.combinedSessionState, button: .right),
                  !CGEventSource.buttonState(.combinedSessionState, button: .center) else {
                return Unmanaged.passUnretained(event)
            }
            held = true
            // Fn selects a function key on some keyboards; don't forward it to the mouse.
            var flags = event.flags
            flags.remove(.maskSecondaryFn)
            dragging = emit(.leftMouseDown, at: event.location, flags: flags, proxy: proxy)
            if dragging {
                status = "Dragging — release \(key.rawValue) to drop, or press Escape."
                let timer = Timer(timeInterval: 60, repeats: false) { [weak self] _ in
                    self?.releaseDrag()
                    self?.status = "Drag released after 60 seconds. Release the key before dragging again."
                }
                deadline = timer
                RunLoop.main.add(timer, forMode: .common)
            } else {
                status = "Could not create a mouse event."
            }
            return nil
        }
        if type == .keyUp && code == key.code && held {
            releaseDrag(proxy: proxy, event: event)
            held = false
            return nil
        }
        if type == .leftMouseUp && swallowLeftUp {
            swallowLeftUp = false
            return nil
        }
        if dragging {
            switch type {
            case .mouseMoved, .leftMouseDragged:
                event.type = .leftMouseDragged
                event.flags.remove(.maskSecondaryFn)
                event.setIntegerValueField(.mouseEventButtonNumber, value: 0)
                event.setIntegerValueField(.mouseEventClickState, value: 1)
            case .leftMouseDown:
                swallowLeftUp = true
                return nil
            case .leftMouseUp:
                return nil
            case .rightMouseDown, .otherMouseDown:
                releaseDrag(proxy: proxy, event: event)
            default:
                break
            }
        }
        return Unmanaged.passUnretained(event)
    }
}
