# KB96 Control — small macOS version

A menu-bar utility for using a JOMAA KB96 trackpad with a Mac mini. macOS 13 or later; Apple Silicon or Intel. No external packages, firmware changes, or system extensions.

This is a deliberately small adaptation of [the original requirements](KB96_Control_macOS_Requirements.md). Source was written on Linux; **it has not been compiled, run, or hardware-tested**. The first Mac build and device trial are still needed.

## What is implemented

- Hold F6 to press the left mouse button, move the trackpad to drag, release F6 to drop. F7, F8 and F9 are alternative activation keys.
- Escape releases a drag. Control + Option + Command + Escape releases and disables the helper.
- Menu-bar enable/disable, settings window, saved activation key. The helper starts disabled and disables on sleep or session deactivation.
- Ordinary pointer motion is converted to left-button drag motion while the key is held. Existing macOS clicking, scrolling and tracking speed remain in use.
- A read-only HID inspector: device identity, HID elements, raw report bytes, decoded scalar values, connect/disconnect updates and a diagnostic text export. JOMAA / KB96 name matches are suggested; no vendor/product IDs are guessed.

The drag helper uses system pointer events, so it applies to **all pointing devices while the activation key is held**. It requires the KB96 to already move the pointer in macOS. It cannot make an unrecognized USB/Bluetooth device work. It does not seize the trackpad or decode a proprietary multitouch protocol. Custom finger gestures, tap-and-hold recognition, speed overrides and profiles are deferred until actual device reports are available.

## Build on your Mac

1. Copy this whole folder to the Mac mini.
2. Install Apple's Xcode Command Line Tools if needed: `xcode-select --install`.
3. In Terminal, change to this folder, then run:

   ```bash
   bash scripts/build-macos.sh
   ```

4. Move `dist/KB96 Control.app` to `/Applications` and open it. The script builds for the Mac's current architecture and applies an ad-hoc signature for local use. It does not produce a notarized distribution build.
5. Click **Grant Accessibility…**, enable **KB96 Control** in System Settings → Privacy & Security → Accessibility, then enable the helper. For HID capture, also grant Input Monitoring when requested. Quit and reopen after permission changes if necessary.

Use the bundled `.app` rather than `swift run` so permissions belong to a stable app path. Rebuilding an ad-hoc signed app can require removing and re-adding it in Privacy & Security settings.

## Launch at login

After moving the app to `/Applications`, open it once. It automatically registers to open when you sign in to your Mac. In the **General** tab, use **Launch at login** to turn this off or back on. If macOS requires approval, use **Open Login Items Settings…** and allow KB96 Control. Changes made in System Settings are reflected when you return to the app.

Automatic startup opens the app; the drag helper still starts disabled. Enable the helper when you are ready to use it.

## Try dragging

1. Choose the activation key and enable the helper.
2. Put the pointer on a window title bar or a file in Finder.
3. Hold F6, move one finger, then release F6.
4. For a screenshot area, press Command + Shift + 4, release those keys, position the crosshair, then hold F6, move, and release.

If F6 performs a media/system action, use **Fn + F6**, or configure the keyboard to use standard function keys. The chosen unmodified function key is consumed while the helper is enabled. Modified shortcuts pass through unless the key is already held for dragging. Existing physical button drags are left alone. Avoid tapping/clicking the trackpad during a key-controlled drag.

Escape releases the button; the activation key must be released before another drag begins. The emergency chord, menu's **Release and Disable**, sleep, normal quit and an interrupted event tap also release the button. A 60-second limit handles a missed key-up. After a forced process kill or crash, a physical click/release may be needed to clear a synthetic drag; this prototype has no separate recovery process.

## Capture the trackpad for the next iteration

1. Open **HID Inspector**, click **Scan Devices**, and select the Jomaa interface. If the name is generic, unplug/reconnect the trackpad and compare the list. Multiple entries may belong to the same physical trackpad.
2. Start capture. Try one-finger motion, taps, physical press/release, press-and-move, two-finger scroll, and multi-finger gestures.
3. Stop and export diagnostics. For a busy device, clear and export a separate short capture for each gesture. The log retains 500 lines, throttles busy streams, and shows the first 128 bytes of each report; truncation is marked.
4. Repeat for other trackpad interfaces if needed. Discovery does not open the listed devices. Only the selected interface is opened for capture and its input is logged. A selected keyboard interface can include keystroke codes, so avoid typing private text during capture.

Digitizer elements such as Contact ID, Tip Switch and Contact Count are labeled when present. Their presence in a descriptor alone does not establish that usable multitouch contacts are sent. Unknown/vendor-defined reports remain hex bytes. A silent capture may mean the wrong interface, missing Input Monitoring permission, or a report path macOS does not expose to this app.

Send back the build error (if any), macOS version, USB/Bluetooth connection type, which drag steps worked, and the exported capture for any failing gesture. Screenshot selection and Finder dragging are intended behaviors awaiting your Mac test.

## Source map

- `Sources/KB96Control/App.swift`: menu bar and SwiftUI settings/inspector.
- `Sources/KB96Control/DragController.swift`: event tap and drag lifecycle.
- `Sources/KB96Control/HIDInspector.swift`: nonexclusive HID access and diagnostics.
- `Sources/KB96Control/LoginItemController.swift`: launch-at-login registration and status.
- `scripts/build-macos.sh`: creates the local macOS app bundle.

HID discovery uses Apple's [independent-device manager option](https://github.com/apple-oss-distributions/IOKitUser/blob/main/hid.subproj/IOHIDManager.h) so opening the manager does not open every discovered device.

API references: [Apple CGEvent documentation](https://developer.apple.com/documentation/coregraphics/cgevent) and [IOHIDDeviceRegisterInputReportCallback](https://developer.apple.com/documentation/iokit/1588666-iohiddeviceregisterinputreportca).
